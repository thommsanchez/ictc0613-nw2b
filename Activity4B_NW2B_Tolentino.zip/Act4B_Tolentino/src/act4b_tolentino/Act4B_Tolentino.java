package act4b_tolentino;

import java.util.Scanner;

public class Act4B_Tolentino {
    
    int[] array = new int[5];
    int aSize = 0;
    
    public static void main(String[] args) {
      Act4B_Tolentino a = new Act4B_Tolentino();
      Scanner scan = new Scanner(System.in);
      
      String option;
      while(true){
          System.out.println ("\nOptions" + "\n1. Insert a value" + "\n2. Delete a value" + "\n3. Traverse the array" + "\n4. Exit");
          System.out.print("Enter your preferred option: ");
          option = scan.nextLine();
          
          switch (option) {
              case "1":
                  System.out.print("Enter element: ");
                  a.insert(Integer.parseInt(scan.nextLine()));
                  break;
              case "2": 
                  System.out.print("Enter element to deleted: ");
                  a.delete(Integer.parseInt(scan.nextLine()));
                  break;
              case "3":
                  a.traverse();
                  break;
              case "4":
                  System.exit(0);
              default:
                  System.out.print("Input number 1 to 4 only ");
                  System.out.println();
          }
      }
    }
    
    void insert(int element){
        if (aSize < array.length) {
            int insert = findLocationInsert(element);
            
            for (int i = aSize - 1; i >= insert; i--) {
                array[i + 1] = array[i];
            }
            array[insert] = element;
            aSize++;
        }   
    }
    
    void delete(int element){
        int delete = findLocationDelete(element);
        if (delete != -1) {
            for (int i = delete + 1; i < aSize; i++) {
                array[i - 1] = array[i];
            }
            aSize--;
        }
    }
    
    void traverse() {
        System.out.println("The size of the array is " + array.length);
        System.out.print("Array elements: ");
        
        for (int i = 0; i < aSize; i++) { 
            System.out.print(array[i] + " ");
        }
        System.out.println(); 
    }

    int findLocationInsert(int element){
        for (int i = 0; i < aSize; i++) {
            if (array[i] > element) {
                return i;
            }
        }  
        return aSize;
    }

    int findLocationDelete(int element) {
        for (int i = 0; i < aSize; i++) {
            if (array[i] == element) {
                return i;
            }
        }
        return -1;
    }
}
