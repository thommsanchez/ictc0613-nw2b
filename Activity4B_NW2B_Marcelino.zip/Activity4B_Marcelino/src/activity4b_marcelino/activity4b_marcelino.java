package activity4b_marcelino;

import java.util.Scanner;

public class activity4b_marcelino{
 private int[] array;
 private int arraySize;

 public activity4b_marcelino() {
 this(5);
 }

 public activity4b_marcelino(int size) {
 array = new int[size];
 arraySize = 0;
 }

 public void insertValue(int item) {
 if (arraySize < array.length) {
 int insertLocation = LocateInsert(item);
 for (int i = arraySize - 1; i >= insertLocation; i--) {
 array[i + 1] = array[i];
 }
 array[insertLocation] = item;
 arraySize++;
 }
 }

 private int LocateInsert(int item) {
 for (int i = 0; i < arraySize; i++) {
 if (array[i] > item) {
 return i;
 }
 }
 return arraySize;
 }

 public void deleteValue(int item) {
 int deleteLocation = LocateDelete(item);
 if (deleteLocation != -1) {
 for (int i = deleteLocation + 1; i < arraySize; i++) {
 array[i - 1] = array[i];
 }
 arraySize--;
 }
 }

 private int LocateDelete(int item) {
 for (int i = 0; i < arraySize; i++) {
 if (array[i] == item) {
 return i;
 }
 }
 return -1;
 }

 public void printArray() {
 System.out.print("Array Elements: ");
 for (int i = 0; i < arraySize; i++) {
 System.out.print(array[i] + " ");
 }
 System.out.println();
 }


  public static void main(String[] args) {
      
 activity4b_marcelino sortedLinearArray = new activity4b_marcelino();
 Scanner in = new Scanner(System.in);
 
 System.out.println("Array capacity is 5.");
 
 String choice;
 while (true) {
 System.out.println("\n1. Insert a value" + "\n2. Delete a value" + "\n3. Traverse the array" + "\n4. Exit");
 System.out.print("Choose a number: ");
 choice = in.nextLine();
 switch (choice) {
 case "1":
 System.out.print("Insert element: ");
 sortedLinearArray.insertValue(Integer.parseInt(in.nextLine()));
 break;
 case "2":
 System.out.print("Choose element you want to delete: ");
 sortedLinearArray.deleteValue(Integer.parseInt(in.nextLine()));
 break;
 case "3":
 sortedLinearArray.printArray();
 break;
 case "4":
 System.exit(0);
 default:
     System.out.println("Please choose from numbers 1-4 only");
 }

 }
 }
}

