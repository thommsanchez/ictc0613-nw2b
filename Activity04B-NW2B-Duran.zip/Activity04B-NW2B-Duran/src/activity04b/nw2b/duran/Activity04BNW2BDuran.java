package activity04b.nw2b.duran;
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Activity04BNW2BDuran {

    public int [] insert (int size, int [] array, int a ){
      int element[] = new int [size + 1];
      for (int b = 0; b<size; b++)
          element[b] = array[b];
          element[size] = a;
          System.out.println("Output: " + Arrays.toString(element));
          return element;
          
      }
      
      public int[] findLocationDelete(int[] array, int index){
          if (array == null || index < 0 || index >= array.length){
              return array;
          }
          return IntStream.range(0, array.length)
                  .filter(i -> i !=index)
                  .map(i-> array[i])
                  .toArray();
                  }
      
      public int[] transverse(int[]arr)
      {
          System.out.print("Array is: ");
                
                if(arr.length == 0){
                    System.out.println(" empty");
                }
                else{
                    System.out.println(" not empty");
                }
                return arr;
            }
      
      
      
          
    public static void main(String[] args) {
        
        Activity04BNW2BDuran exobj = new Activity04BNW2BDuran();
        Scanner s = new Scanner(System.in);
        System.out.print("Input size of Array: ");
        int size = s.nextInt();
        int arr[] = new int [size];
    System.out.print("Enter value for Array: ");
    
    for(int i = 0; i<size; i++){
        arr[i] = s.nextInt();
    }
        
        System.out.println("Choices: ");
        System.out.println("1. Insert a value" + "\n" + "2. Delete a value" + "\n" + "3.Transverse array" + "\n" + "4. Exit");
        System.out.println("Select option: ");
        int choice = s.nextInt();
        
        
        
        
        
        switch(choice){
            case 1: 
                System.out.print("Enter a value to be inserted: ");
                int b = s.nextInt();
                arr = exobj.insert(size,arr,b);
                    
                break;
            
            case 2:
                System.out.println("Enter the number of index to delete: ");
                int index= s.nextInt();
                arr = exobj.findLocationDelete(arr, index);
                System.out.println("Output: " + Arrays.toString(arr));
            
                break;
                
            case 3:
                System.out.println("The Array contains: " + Arrays.toString(arr));
                arr = exobj.transverse(arr);
                break;
                
            case 4:
                System.out.println("Exit done!");
                System.exit(0);
                
            default:
                System.out.print("Invalid Input");
                break;
        }
      }
    }


   