
package activity4b_nw2b_ramos;
import java.util.*;

public class Activity4B_NW2B_Ramos {

  
 private String Insert;
 private String Delete;
 private String Traverse;
 private String Exit;
 
 
 
 private static String names[] = new String[5];
    private static String new_names[] = new String[names.length-1];
    private static Scanner scan;

    private static String option = "Select an option:"
                + "\n1.Insert a value"
                + "\n2.Delete a value"
                + "\n3.Transverse array"
                + "\n4.Exit\n";

    public static void main(String[] args) {
        scan = new Scanner(System.in);

        System.out.println(option);
        System.out.print("Please select an option from 1 to 4: ");

        if(scan.hasNextInt()){
           chooseOption(); 
           
         } else {
            System.out.println("Please enter numbers from 1-4 only\n");          
            chooseOption();
        }
    }

    public static void chooseOption(){
        switch(scan.nextInt()){
            case 1: //insert a value
                System.out.println("\nEnter " + names.length + " names");

                for (int i = 0; i < names.length; i++) {
                    System.out.print("Name " + (i+1) + ": ");
                    names[i] = scan.next();   
                }

               
                break;

            case 2: //delete a value
                if(names[0] != null){
                    System.out.print("Delete value: ");    
                    String value = scan.next();

                    for (int i = 0, n = 0; i < names.length; i++) {
                        if(i != findLocationDelete(value))
                        new_names[n++] = names[i];
                    }
                } else {
                    System.out.println("Array is empty");
                }

                
                break;   

            case 3: //transverse the array
                System.out.println("Name List: Rencel John ");
                System.out.print(" Rencel");
                System.out.print(" John");
                System.out.print(" Ramos");

            {
                String[] Rencel = null;
              
                if(new_names != Rencel){
                    for (int i = 0; i < new_names.length; i++) {
                        System.out.println(new_names[i]);
                    } 
                } else {
                    for (int i = 0; i < names.length; i++) {
                        System.out.println(names[i]);
                    } 
                }
            }

                
                break;



            case 4: //exit
                System.exit(0);
                break;

            
        }
    }

   
    public static int findLocationDelete(String value){ 
        int position = 0;
        for (int i = 0; i < names.length; i++) {
            if(names[i].toString().equals(value))
            position = i;
        }
        return position;
    }

}
    
    
