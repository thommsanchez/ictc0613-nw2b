package SecondYear;

import java.util.*;

public class Activity4B_NW2B_Abad {
    private static String nms[] = new String [5];
    private static String nnms[] = new String[nms.length];
    private static int num[] = {1, 2, 3, 4, 5};
    private static String dsh = "- ";
    private static Scanner myObj;
    
    private static String optns = "Options:\n" + num[0] +". Insert a value\n" + num[1] + ". Delete a value\n" + num[2] + ". Transverse array\n" + num[3] + ". Exit\n";
    
    public static int findLocationDelete(String value){
        int pstn = 0;
        for (int i = 0; i < nms.length; i++) {
            if(nms[i].toString().equals(value))
            pstn = i;
        }
        return pstn;
    }
    
    public static void main(String[] args) {
        myObj = new Scanner(System.in);
        
        System.out.println("//The size of the array is 5.\n");
        System.out.println(optns);
        System.out.print("Choose an option from options 1-4: ");
        
        if(myObj.hasNext()){
           Options(); 
        } 
        else {
            System.out.println("Choose a number from 1-4 only\n");          
            Options();
        }
    }
    
    public static void Options(){
        switch(myObj.nextInt()){
            case 1:
                System.out.println("\nEnter " + nms.length + " names");
                for (int i = 0; i < nms.length; i++) {
                    System.out.print("Name " + (i+1) + ": ");
                    nms[i] = myObj.next(); 
                }
                OptionsRepeat();
                break;
                
            case 2:
                if(nms[0] != null){
                    System.out.print("Delete value: ");    
                    String value = myObj.next();
                
                    for (int i = 0, n = 0; i < nms.length; i++) {
                        if(i != findLocationDelete(value))
                        nnms[n++] = nms[i];
                    }
                } else {
                    System.out.println("Array is empty");
                }
                OptionsRepeat();
                break;   
                
            case 3:
                System.out.println("Name List: ");
                
                if((nnms != null)){
                    for (int i = 0; i < nnms.length; i++) {
                        System.out.println(dsh + nnms[i]);
                    } 
                } 

                else {
                   for (int i = 0; i < 1; i++) {
                        System.out.println(dsh + num[i]);
                    } 
                }
                OptionsRepeat();
                break;
                
            case 4:
                break;
                
            default:
                System.out.println("(Please enter numbers from 1-4 only.)");
                OptionsRepeat();
                break;
        }
    }

    public static void OptionsRepeat(){
        System.out.print("\nDo you want to choose another option? Y/N: ");
                if(myObj.next().toUpperCase().equals("Y")){
                    System.out.println("\n" + optns);
                    System.out.print("Option: ");
                    Options();
                }
    }
}