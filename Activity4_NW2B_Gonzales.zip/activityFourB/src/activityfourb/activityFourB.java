package activityfourb;
import java.util.Scanner;


public class activityFourB {
 public static void main(String[] args) {
 SortedLinearArray sortedLinearArray = new SortedLinearArray();
 Scanner in = new Scanner(System.in);
 String choice;
 while (true) {
 System.out.println("\n1. Insert a value"
 + "\n2. Delete a value"
 + "\n3. Traverse the array"
 + "\n4. Exit");
 System.out.print("Enter your choice: ");
 choice = in.nextLine();
 switch (choice) {
 case "1":
 System.out.print("Enter element to inserted: ");
 sortedLinearArray.insertItem(Integer.parseInt(in.nextLine()));
 break;
 case "2":
 System.out.print("Enter element to deleted: ");
 sortedLinearArray.deleteItem(Integer.parseInt(in.nextLine()));
 break;
 case "3":
 sortedLinearArray.printArray();
 break;
 case "4":
 System.exit(0);
 }

 }
 }
}