package act04b_nw2b_marcelo;
 
import java.util.Arrays;
import java.util.Scanner;

public class Act04B{
    static int length;
    static Scanner scan = new Scanner(System.in);
  
  
  public static void insert(){
     int elem; 
        System.out.print("Enter Array length: ");
        length = scan.nextInt();
        int arr[] = new int[length+1];
        System.out.println("\nEnter "+length+" Element to Store in Array");
        for(int i = 0; i < length; i++)
        {
            arr[i] = scan.nextInt();
        }
        System.out.print("Enter the element which you want to insert: ");
        elem = scan.nextInt();
        arr[length] = elem;
        System.out.print("After inserting an element: ");
        for(int i = 0; i <length; i++)
        {
            System.out.print(arr[i]+",");
        }
        scan.close();
        System.out.print(arr[length]); 
  }
  
  public static void delete(){
     
        int index, i = 0;
        System.out.print("Enter Array length: ");
        length = scan.nextInt();
        int arr[] = new int[length];
        System.out.println("Enter "+length+" Element to Store in Array");
        for(i = 0; i < length; i++)
        {
            arr[i] = scan.nextInt();
        }
        System.out.print("Enter the index of the element that you want to be deleted: ");
        index = scan.nextInt();
        System.out.println("\nElement to be deleted at index: "+ index); 
 
        int[] copyArr = new int[arr.length - 1]; 
 
        System.arraycopy(arr, 0, copyArr, 0, index); 
 
        System.arraycopy(arr, index + 1, copyArr, index, arr.length - index - 1); 
        scan.close();
        System.out.println("Array after deleting an element: "+ Arrays.toString(copyArr));  
  }
  
  public static void traverse(){
        
        
        System.out.print("How many names you want to enter?: ");
        length = Integer.parseInt(scan.nextLine());
        
        String names[] = new String[length];
        System.out.println("Enter "+length+" names to Store in Array:");
        for(int i = 0; i < names.length; i++)
        {
            names[i] = scan.nextLine();
        }
         scan.close();
        System.out.print("\nThe names in Array are:\n");
        
        for(int i = 0; i < names.length; i++) {
             System.out.print(names[i]+"\n");
        }
  }
  
  public static void exit(){
      System.out.println("Program Exit");
  }
 
  public static void main(String[] args) {
      {
          System.out.println();
          System.out.print("\t\tChoose Options\n\t\t (1) for Insert \n\t\t (2) for Delete \n\t\t (3) for Traverse \n\t\t (4) for Exit \n");
          System.out.println("***********************************************");
          System.out.print("Enter the operations(number) you want to perform?: ");
          int choice = scan.nextInt();
          System.out.println();
          switch(choice){
              case 1:
                  insert();
                  break;
              case 2:
                  delete();
                  break;
              case 3:
                  traverse();
                  break;
              case 4:
                  exit();
                  break;
          }
          System.out.println();
      }
  }
}

