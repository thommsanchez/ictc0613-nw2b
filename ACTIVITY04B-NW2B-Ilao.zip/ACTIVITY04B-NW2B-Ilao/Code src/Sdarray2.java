import java.util.Scanner;

public class Sdarray2 {
    int arr[];

  
    public void traverse()
    {
      
        for (int res:arr) {
            System.out.println(res);
        }
    }
    
    public void insert(int location, int value )
    {
        try
        {
            if(arr[location]== Integer.MIN_VALUE)
            {
                arr[location]= value;
            }
            else
            {
                System.out.println("already filled");
            }
        }catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("invalid index");
        }
    }
    // method to delete a particular index value from the array
    public void delete(int index) {
        int i = 0;
        try {
            for (i = index; i < arr.length - 1; i++)

                arr[i] = arr[i + 1];

            arr[i] = 0;
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("invalid index");
        }
    }
 
}
class Check
{
    public static void main(String[] args) {
        Sdarray2 obj = null;
      
        Scanner sc= new Scanner(System.in);
        int v=1;
        while(v!=0){
            System.out.println("\nWelcome to the Array Menu");
          
            System.out.println("1 - To insert value in the array.");
            System.out.println("2 - To print the array.");
           
           
            System.out.println("3 - To delete a particular index value from the array.");
          
            System.out.println("4 - To Exit the Menu.");
            System.out.print("Enter your choice: ");
            v=sc.nextInt();

            switch (v){
              
                case 1 : {
                    System.out.print("\nEnter the value you want to insert: ");
                    int val=sc.nextInt();
                    System.out.print("Enter the index at which you wish to insert: ");
                    int i=sc.nextInt();
                    obj.insert(i,val);
                    System.out.println("\nValue has been inserted in the desired location.");
                }
                case 2 : {
                    System.out.println("\nDisplaying the array:");
                    obj.traverse();
                }
              
               
                case 3 : {
                    System.out.print("\nEnter the index of value you want to delete: ");
                    int i=sc.nextInt();
                    obj.delete(i);
                    System.out.println("\nAfter delete");
                    obj.traverse();
                }
                case 4 : {
                    System.exit(0);
                }
            }
        }
        sc.close();
    }
}