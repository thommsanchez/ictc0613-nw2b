package activity4b_nw2b_albais;

import java.util.Scanner;

public class Activity4B_NW2B_Albais {
    
    static Scanner input;
    static String array[] = new String[5];
    static String new_array[] = new String[array.length-1];
   
    
    private static String choices = "Select an option:"
                + "\n1.Insert a value"
                + "\n2.Delete a value"
                + "\n3.Transverse array"
                + "\n4.Exit\n";
    
    public static void main(String[] args) {
        
        input = new Scanner(System.in);
        
        System.out.println(choices);
        System.out.print("Option Selected: ");
        
        if(input.hasNextInt()){
           Options(); 
        } else {
            System.out.println("Enter number 1-4 only\n");          
            Options();
        }
    }
    
    public static void Options(){
        switch(input.nextInt())
        {
            case 1:
                System.out.println("\nEnter " + array.length + " value: ");
                
                for (int i = 0; i < array.length; i++) 
                {
                    System.out.print("Value " + (i+1) + ": ");
                    array[i] = input.next();   
                }
                repeatOption();
                break;
            case 2:
                if(array[0] != null)
                {
                    System.out.print("Delete value: ");    
                    String value = input.next();
                
                    for (int i = 0, n = 0; i < array.length; i++) 
                    {
                        if(i != findLocationDelete(value))
                        new_array[n++] = array[i];
                    }
                } else 
                {
                    System.out.println("Array is empty");
                }
                repeatOption();
                break;
            case 3:
                System.out.println("Value List: ");
                
                if(new_array != null)
                {
                    for (int i = 0; i < new_array.length; i++) 
                    {
                        System.out.println(new_array[i]);
                    } 
                } else 
                {
                   for (int i = 0; i < array.length; i++) 
                    {
                        System.out.println(array[i]);
                    } 
                }
                repeatOption();
                break;
            case 4:
                break;
            default:
                System.out.println("Please enter numbers from 1-4 only");
                break;
        }
    }
    public static void repeatOption(){
        System.out.print("Do you want to choose another option? Y/N: ");
                if(input.next().toLowerCase().equals("y"))
                {
                    System.out.println("\n" + choices);
                    System.out.print("Option: ");
                    Options();
                }
    }
    public static int findLocationDelete(String value){
        int position = 0;
        for (int i = 0; i < array.length; i++) 
        {
            if(array[i].toString().equals(value))
            position = i;
        }
        return position;
    }
    
}
